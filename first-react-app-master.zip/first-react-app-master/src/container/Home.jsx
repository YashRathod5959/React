import React, { Component } from 'react'
import Blog from './blog/Blog'

class Home extends Component {
    render() {
        return (
            <div>
                <Blog />
            </div>
        )
    }
}

export default Home;